# resume_html 数据集归档（L0-L3）

生成时间：2026-11-14T12:55:27
归档范围：data_inventory 清单中的 L0 / L1 / L2 / L3 四层，共 2496 个文件、87.9 MB（未压缩）。
未归档：L4 模型交付（jobfit_project/ 主体、jobfit_project.zip）与 L5 辅助记录
（.workbuddy/、data_inventory.*、4 字节残留文件），均保留在原位。

## 目录结构
- L0_raw/resume_html/  2,484 个简历 HTML 片段（resume0.html ~ resume2483.html）
- L0_raw/tag.csv       2,484 行岗位标签，无表头，label 带前导空格
- L0_raw/JDList.txt    上级目录 AI-recruitment/JDList 的只读副本（原件未改动）
- L1_extracted/        resumes.csv 等 5 张抽取表（主表 + 经历/教育/板块/条目明细）
- L2_structure/        structure_groups.csv、structure_report.html、extraction_report.html
- L3_job_jd/           jobexample.csv、jobs.example.csv（24 岗英文 JD，二者内容相同）
- manifest.json        逐文件字节数 / CRC32 / SHA-256，可用于完整性校验

## 还原方式
解压后按上述目录取用。若需重跑 jobfit 训练，把 L0_raw/resume_html/ 与
L0_raw/tag.csv、L1_extracted/ 全部文件放回同一目录（即训练时的 data-dir），
再把 L3_job_jd/jobexample.csv 复制为 <data-dir>/jobs.csv，并确保
jobfit_project/configs/default.json 的 jobs_file 指向它。

## 注意事项
1. 原始 HTML 为 div 片段，无 doctype；5 个文件标签破损：1657/1831/1933/2035/2170。
2. CSV 均为 UTF-8 BOM 编码；tag.csv 无表头。
3. structure_report.html 内文件链接为相对路径，需与 resume_html/ 同级用本地浏览器打开。
4. 中文 JD 对当前模型无效（分词器只抽取英文小写字母数字）；零样本 --jd-text 分支未训练。
5. 上级目录 AI-recruitment/JDList 原件不在本次归档/清理范围内，包内仅为副本。
